import React from 'react';
import { Heart, Menu } from 'lucide-react';
import { Container } from './layout/Container';
import { NAV_ITEMS } from '../constants/navigation';

export function Header() {
  return (
    <header className="bg-white shadow-sm">
      <Container>
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center">
            <Heart className="h-8 w-8 text-rose-600" />
            <span className="ml-2 text-xl font-bold text-gray-900">HealthConnect</span>
          </div>
          <nav className="hidden md:flex space-x-8">
            {NAV_ITEMS.map((item) => (
              <a 
                key={item.label}
                href={item.href} 
                className="text-gray-700 hover:text-rose-600"
              >
                {item.label}
              </a>
            ))}
          </nav>
          <div className="md:hidden">
            <Menu className="h-6 w-6 text-gray-600" />
          </div>
        </div>
      </Container>
    </header>
  );
}