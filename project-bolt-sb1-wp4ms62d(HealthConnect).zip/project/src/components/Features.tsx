import React from 'react';
import { IconBox } from './ui/IconBox';
import { SectionTitle } from './ui/SectionTitle';
import { Container } from './layout/Container';
import { FEATURES } from '../constants/features';

export function Features() {
  return (
    <div className="py-16 bg-white">
      <Container>
        <SectionTitle 
          title="Why Choose HealthConnect?"
          subtitle="We're committed to making healthcare accessible to everyone, everywhere."
        />

        <div className="mt-16">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {FEATURES.map((feature, index) => (
              <IconBox
                key={index}
                Icon={feature.icon}
                title={feature.title}
                description={feature.description}
              />
            ))}
          </div>
        </div>
      </Container>
    </div>
  );
}