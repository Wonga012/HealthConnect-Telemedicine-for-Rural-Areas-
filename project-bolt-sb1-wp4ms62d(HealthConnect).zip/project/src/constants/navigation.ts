export const NAV_ITEMS = [
  { label: 'Home', href: '#' },
  { label: 'Find Doctor', href: '#' },
  { label: 'My Records', href: '#' },
  { label: 'Support', href: '#' }
];