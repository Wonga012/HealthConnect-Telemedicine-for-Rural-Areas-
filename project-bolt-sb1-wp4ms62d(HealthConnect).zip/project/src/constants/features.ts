import { Shield, Wifi, Users, Video, Calendar, FileText } from 'lucide-react';
import { Feature } from '../types';

export const FEATURES: Feature[] = [
  {
    icon: Shield,
    title: "Secure & Private",
    description: "Your health data is protected with enterprise-grade security and encryption."
  },
  {
    icon: Wifi,
    title: "Works Offline",
    description: "Access essential features even with limited internet connectivity."
  },
  {
    icon: Users,
    title: "Expert Doctors",
    description: "Connect with qualified healthcare professionals specialized in various fields."
  }
];

export const SERVICES: Feature[] = [
  {
    icon: Video,
    title: "Virtual Consultations",
    description: "Connect with doctors through secure video calls"
  },
  {
    icon: Calendar,
    title: "Easy Scheduling",
    description: "Book appointments at your convenience"
  },
  {
    icon: FileText,
    title: "Medical Records",
    description: "Access your health records securely anytime"
  }
];